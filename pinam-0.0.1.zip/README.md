# Pi Network Amount Manager 

A program that controls the 'Pi Network Amount Manager' application.

1. Run 'Pi Node' App on Windows
2. Browse chat page such as ''Pioneers (日本語)''
3. just click pinam as ok

Contact : info@shine57.shop

https://ja.wikipedia.org/wiki/UWSC
